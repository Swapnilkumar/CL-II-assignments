import java.rmi.*;
import java.rmi.server.*;

public class Hydra3c extends UnicastRemoteObject implements Hydra3
{
public Hydra3c() throws RemoteException
{
System.out.println("Ready");
}

public int get_rand() throws RemoteException
{
return 4;
}
}

