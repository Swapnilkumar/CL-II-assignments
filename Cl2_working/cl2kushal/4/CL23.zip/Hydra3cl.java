import java.rmi.*;
public class Hydra3cl
{
public static void main(String[] argv)
{
try{

Hydra3 ro=(Hydra3) Naming.lookup("//192.168.5.25/Hydra3c");
System.out.println(ro.get_rand());
}
catch (Exception e)
{

}

}
}
