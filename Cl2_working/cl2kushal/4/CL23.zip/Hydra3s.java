import java.rmi.*;
public class Hydra3s
{
public static void main(String[] argv)
{
try{
Naming.rebind("Hydra3c",new Hydra3c());
System.out.println("Jawohl");
}
catch (Exception e)
{

}
}
}
