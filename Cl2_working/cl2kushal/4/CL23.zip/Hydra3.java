import java.rmi.*;

public interface Hydra3 extends Remote
{

public int get_rand() throws RemoteException;
}
